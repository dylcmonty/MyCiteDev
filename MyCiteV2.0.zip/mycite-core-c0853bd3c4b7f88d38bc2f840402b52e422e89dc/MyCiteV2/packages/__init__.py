"""Inert package scaffold."""
