from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from flask import abort, jsonify, make_response, request
from portal.services.runtime_paths import alias_read_dirs


def _aliases_dir(private_dir: Path) -> Path:
    return alias_read_dirs(private_dir)[0]


def _alias_paths(private_dir: Path, alias_id: str) -> list[Path]:
    return [directory / f"{alias_id}.json" for directory in alias_read_dirs(private_dir)]


def _read_json(path: Path) -> Dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Expected object JSON in {path}")
    return payload


def _safe_alias_id(alias_id: str) -> str:
    normalized = (alias_id or "").strip()
    if (
        not normalized
        or "/" in normalized
        or "\\" in normalized
        or ".." in normalized
    ):
        raise ValueError("alias_id must be a stable identifier, not a path")
    return normalized


def list_alias_records(private_dir: Path) -> Tuple[List[Dict[str, Any]], Dict[str, str]]:
    directories = [path for path in alias_read_dirs(private_dir) if path.exists() and path.is_dir()]
    if not directories:
        return [], {}

    items: List[Dict[str, Any]] = []
    errors: Dict[str, str] = {}
    seen_alias_ids: set[str] = set()

    for aliases_path in directories:
        for alias_path in sorted(aliases_path.glob("*.json")):
            alias_id = alias_path.stem
            if alias_id in seen_alias_ids:
                continue
            seen_alias_ids.add(alias_id)
            try:
                payload = _read_json(alias_path)
            except Exception as e:
                errors[alias_id] = f"Failed to read alias JSON: {e}"
                continue

            record = dict(payload)
            record.setdefault("alias_id", alias_id)
            items.append(record)

    return items, errors


def get_alias_record(private_dir: Path, alias_id: str) -> Dict[str, Any]:
    safe_alias_id = _safe_alias_id(alias_id)
    alias_path = next(
        (path for path in _alias_paths(private_dir, safe_alias_id) if path.exists() and path.is_file()),
        None,
    )
    if alias_path is None:
        raise FileNotFoundError(f"No alias record found for alias_id={safe_alias_id}")

    payload = _read_json(alias_path)
    record = dict(payload)
    record.setdefault("alias_id", safe_alias_id)
    return record


def register_aliases_routes(
    app,
    *,
    private_dir: Path,
    options_private_fn: Optional[Callable[[str], Dict[str, Any]]] = None,
):
    @app.get("/portal/api/aliases")
    def portal_aliases_get():
        msn_id = (request.args.get("msn_id") or "").strip()
        if not msn_id:
            abort(400, description="Missing required query param: msn_id")

        records, errors = list_alias_records(private_dir)
        aliases: Dict[str, Any] = {}

        for record in records:
            alias_id = str(record.get("alias_id") or "").strip()
            if not alias_id:
                continue
            alias_msn_id = str(record.get("msn_id") or "").strip()
            if alias_msn_id and alias_msn_id != msn_id:
                continue
            aliases[alias_id] = record

        out: Dict[str, Any] = {
            "msn_id": msn_id,
            "schema": "mycite.alias.bundle.v0",
            "aliases": aliases,
            "errors": errors,
        }
        if options_private_fn is not None:
            out["options_private"] = options_private_fn(msn_id)
        return jsonify(out)

    @app.route("/portal/api/aliases", methods=["OPTIONS"])
    def portal_aliases_options():
        resp = make_response("", 204)
        resp.headers["Allow"] = "GET, OPTIONS"
        return resp
